package assignment42;
import java.util.Scanner;

public class calculator {
public static void main(String args []) throws exception
{
	Scanner sc=new Scanner(System.in);
 System.out.println("enter your number :");
 Integer n=sc.nextInt();	
 vali v=new vali();
 if(v.validates(n))
 {
	 System.out.println( ((n*(n+1))/2)/n);
 }
 
 
}
}
