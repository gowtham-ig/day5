package assignment42;


public class vali {
	public boolean validates(Integer num) throws exception
	{
		boolean yes=true;
		if(num<0)
		{
			yes=false;
			throw new exception("enter a positive number");
			
		}
		return yes;
	}

}
