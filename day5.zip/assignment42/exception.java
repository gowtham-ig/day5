package assignment42;

public class exception extends Exception{
	exception(String msg)
	{
		super(msg);
	}

}
