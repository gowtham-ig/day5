package assignment;

public class exec extends Exception{
	exec(String msg){
		//System.out.println(msg);
		super(msg);
		}}

