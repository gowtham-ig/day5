package assignment;

public class dayexeceptions {
	private String Firstname;
	private String Middlename;
	private String Lastname;
	private String Dateofbirth;
	private String Gender;
	private String Mobilenumber;
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getMiddlename() {
		return Middlename;
	}
	@Override
	public String toString() {
		return "contact [Firstname=" + Firstname + ", Middlename=" + Middlename + ", Lastname=" + Lastname
				+ ", Dateofbirth=" + Dateofbirth + ", Gender=" + Gender + ", Mobilenumber=" + Mobilenumber
				+ "]";
	}
	public void setMiddlename(String middlename) {
		Middlename = middlename;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getDateofbirth() {
		return Dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		Dateofbirth = dateofbirth;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getMobilenumber() {
		return Mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		Mobilenumber = mobilenumber;
	}	
	
	
}
