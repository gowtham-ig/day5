package assignment;
import java.util.*;

public class atteval {
	public static void main(String [] args) throws exec
	{
		Scanner sc =new Scanner(System.in);
		boolean something =true;
		System.out.println("enter the size of the stack");
		int size=sc.nextInt();
		contact c=new contact();
		Stack<contact> s1=new Stack<>();
		validate vs=new validate();
		while(something)
		{
		System.out.println("Select you option");
		System.out.println("1.push");
		System.out.println("2.pop");
		System.out.println("3.exit");
		int responce=sc.nextInt();
		String [] arr=new String[6];
		
		
		switch(responce)
		{
		case 1:
			System.out.println("enter your First name, Middle name, Last name, Date of birth, Gender, Mobile number");
			for(int i=0;i<6;i++)
			{
				arr[i]=sc.next();
			}
			
					
			
			vs.ValidateAll(arr);
			c.setFirstname(arr[0]);
			c.setMiddlename(arr[1]);
			c.setLastname(arr[2]);
			c.setDateofbirth(arr[3]);
			c.setGender(arr[4]);
			c.setMobilenumber(arr[5]);
			if(vs.ValidatePush( s1, size))
			{
				s1.push(c);
				System.out.println("succesfully inserted"+s1.peek());
			}
			break;
		case 2:
			if(vs.ValidatePop(s1))
			{
				
				System.out.println("you deleted" + s1.pop());
			}
			break;
			
			
			
		case 3:
			something =false;
			System.out.println("your are exited");
			break;
			
		}
		
			
		
	}
		sc.close();
	}
}


