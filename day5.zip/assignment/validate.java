package assignment;
import java.time.LocalDate;
import java.util.Stack;
public class validate {
	public boolean validateName(String s) throws exec
	{
		boolean yes=true;
		if(s==null)
		{
			yes=false;
			throw new exec("it should not be null");
			//return false;
		}
		System.out.println("name is verified");
		return yes;
	}
	public boolean validateDateOfBirth(String dateOfBirth) throws exec
	{
		boolean yes=true;
		LocalDate today=LocalDate.now();
		LocalDate db=LocalDate.of(Integer.parseInt(dateOfBirth.substring(6)), Integer.parseInt(dateOfBirth.substring(3, 5)), Integer.parseInt(dateOfBirth.substring(0, 2)));
		if(db.isAfter(today))
		{
			yes=false;
			throw new exec("enter correct dob");
		}
		System.out.println("dob is verified");
		return yes;
	}
	public boolean PhoneNumber(String num) throws exec
	{
		boolean yes=true;
		if(num.length()>10||num.length()<10)
		{
			yes=false;
			throw new exec("enter correct phone number");
		}
		System.out.println("phone numbver is verified");
		return yes;
	}
	public boolean ValidateAll(String arr[]) throws exec {
	 validate v=new validate();
	// contact c=new contact();
	 if(v.validateName(arr[0])&&v.validateDateOfBirth(arr[3])&&v.PhoneNumber(arr[5]))
	 {
		 System.out.println("All details are verified and correct");
		return true;	
	}
	 System.out.println("re-enter details some fields are wrong");
	 return false;
	
	
}
	public boolean ValidatePush(Stack<contact> s1,int size) throws exec
	{
		boolean yes=true;
		if(s1.size()==size)
		{
			yes=false;
			throw new exec("you can't add as size is full");
		}
		return yes;
	}
	public boolean ValidatePop(Stack<contact> s1) throws exec
	{
		boolean yes=true;
		if(s1.isEmpty())
		{
			yes=false;
			throw new exec("you can't delete from empty stack");
		}
		return yes;
	}
	}
